KinoIsoline
===========

KinoIsoline is an isoline (contour line) image effect for Unity.

![screenshot](http://40.media.tumblr.com/fa3203f1a513d28a2089ee88d1d40ed8/tumblr_nv8kv6Dk9c1qio469o1_400.png)

![gif](http://33.media.tumblr.com/c500e8004c55b2292f3964381572d54d/tumblr_nva7l4RAcQ1qio469o1_400.gif)
![gif](http://38.media.tumblr.com/e2abb5071a65987b631637ddcdbdc620/tumblr_nvaekweork1qio469o1_400.gif)

License
-------

Copyright (C) 2015 Keijiro Takahashi

Permission is hereby granted, free of charge, to any person obtaining a copy of
this software and associated documentation files (the "Software"), to deal in
the Software without restriction, including without limitation the rights to
use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of
the Software, and to permit persons to whom the Software is furnished to do so,
subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
